using System;

class Program {
  public static void Main (string[] args) {    
    
    Console.Write("Digite o número A: ");
    int a = int.Parse(Console.ReadLine());
    
    Console.Write("Digite o número B: ");
    int b = int.Parse(Console.ReadLine());

    Console.Write ("A soma entra " + a + " e " + b + " é " + (a+b) );

  }
}